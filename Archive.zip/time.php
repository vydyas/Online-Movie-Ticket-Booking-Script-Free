<?php
   echo date("ymdHis").rand(100,999);
?>
<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fsiddhu.info&amp;width=326&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true&amp;appId=673893932704718" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:326px; height:290px;" allowTransparency="true"></iframe>