<header>
	<div class='header-content'>
	<?php
	if(isset($_GET['location']))
	{
		?>
		<a href='index.php'><img src="../../images/logo2.jpg" class='logo'  width='286px' height='100px' title='Online Movie Ticket Booking Site' /></a>
		<!--<img src="images/steps.png" id="movielocation" class='steps'>-->
<?php
	}
	else
	{
		?>
		<a href='index.php'><img src="images/logo2.jpg" class='logo' width='286px' height='100px' title='Online Movie Ticket Booking Site' /></a>
		<!--<img src="images/steps.png" id="movielocation" class='steps'>-->
		
		<?php
	}
	?>
		
		
	</div>

</header>
