<!DOCTYPE HTML>
<html>
	<head>
		<title>Gopala Gopala (2015) Movie Review| Cinemachoodu.com</title>
		
		<meta name="description" content="Gopala Gopala Review, Gopala Gopala Movie Review, Gopala Gopala Rating,Live Updates, Venkatesh, Pawan Kalyan, Gopala Gopala Story, Gopala Gopala Public Talk, Gopala Gopala Telugu Movie Review" />
		<meta name="keywords" content="Gopala Gopala Review, Gopala Gopala Movie Review, Gopala Gopala Rating, Gopala Gopala Live Updates, Venkatesh, Pawan Kalyan, Gopala Gopala Story, Gopala Gopala Public Talk, Gopala Gopala Telugu Movie Review, Gopala Gopala Collections, Gopala Gopala Tweet" />
		<meta name="robots" content="index, follow" /><meta http-equiv="content-language" content="ll-cc">

		<link href="../newui/web/css/style.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/x-icon" href="images/fav-icon.png" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		</script>
		<!----webfonts---->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
		<style type="text/css">
		ul li{padding: 10px;}
		ul li b{color:#3399ff;font-weight: bold;}
		table tr td b{color:#3399ff;font-weight: bold;}
		p{color:#444;}
		</style>

	</head>
	<body>
		<!---start-wrap---->
			<!---start-header---->
			<div class="header">
				<div class="wrap">
				<div class="logo">
					<a href="../index.php"><img src="../newui/web/images/logo.png" title="Online Movie Ticket Booking" alt="Online Movie Ticket Booking" /></a>
				</div>
				<div class="nav-icon">
		
				</div>       	  

				<div class="userinfo">
					<div class="user">
						<ul>
						  <li>
						  </li>
						</ul>
					</div>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		<!---//End-header---->
		<!---start-content---->
		<div class="content">
			<div class="wrap">
			<div class="single-page">
							<div class="single-page-artical">
								<div class="artical-content">
									<div id="articleinfo">
												<img src="Untitled.png" title="Gopala Gopala Movie Review" alt="Gopala Gopala Movie Review"><br/><br/>
												
										</div>
                                     <div id="cinematiming">
									<h1 style="font-size:25px;font-weight:bold">Gopala Gopala (2015) Telugu Movie Review</a></h1><br/>

                            <div>
                            	
                            		<table class="timeselect">
									<tr>
										<td>Telugu - Dec 10th 2014 - U</td>
									</tr>
									<tr>\
										<td><b>Cast:</b>&nbsp;Venkatesh Daggubati,Pawan Kalyan,Sriya Saran</td>
									</tr>
									<tr>
										<td><b>Genre:</b>&nbsp;Comedy,Humanity</td>
									</tr>
									<tr>
										<td><img src="critic.png" alt="Gopala Gopala Movie Rating" title="Gopala Gopala Movie Rating"></td>
									</tr>

								</table><br/><br/>
								<h2 style="font-size:20px;font-weight:bold">Gopala Gopala Review:</h2>
								<ul>
								<li>Live Updates :</b> shortly.. (Pls refresh for minit to minit updates)</li>
								
								<li><b>12:10am :</b>  God Pawan Kalyan saves Venkatesh family from goons..</li>
								<li><b>12:05am :</b>  Power Star Pawan Kalyan The God entry....</li>
								<li><b>12:00am :</b> Goons attack on Venkatesh and his family... </li>
								<li><b>11:35pm :</b> Some intresting scenes are running now... </li>
								<li><b>11:30pm :</b> enkatesh decide to give a complaint on god and the case appears in the court now...</li>
								<li><b>11:25pm :</b> Venkatesh decide to cliam his insurance from insurance company... </li>
								<li><b>11:20pm :</b>Disaster in the city earth quake..... city escape from this incident but Venkatesh shop damaged... </li>
								<li><b>11:15pm :</b> Comedy scenes are running between Venkatesh and Shriya...</li>
								<li><b>11:10 pm :</b> Prasadam Kallki adukuni tinandi - Venkatesh wife.... inka nayam kalalo pettukomanaledu - Venkatesh.... </li>
								<li><b>11:00 pm :</b> Venkatesh didn't belive god, but he is selling the status of god..</li>
								<li><b>10:55 pm :</b> Comedy scenes between Venkatesh and comedians.... </li>
								<li><b>10:50 pm :</b> Voctory Venkatesh nice entry as common man.... </li>
								<li><b>10:45 pm :</b> Titles started with the background gopala gopala logo banner... nicely background music from anoop rubens </li>

									
								</ul><br/><br/>
								<h3 style="font-size:20px;font-weight:bold">Story Of a Movie:</h3><br/>
								<p>
								Victory Venkatesh is a non-believer of God and he belives work is god. His wife (Shriya Sharan) belives god. Venkatesh is looking like a common men and he runs a shop and it affected by earthquake. Venkatesh goes to insurance company to get insurance for his shop, but insurance company peopls rejects his request of insurance.
								</p>
								<p>
								Venkatesh decided to file a case against God. Insurance Company made it clear saying that it is God’s responsibility to compensate him for his losses. In a court Venkatesh argues his own case, because of he didn't belive any laywer. Many people oppose Venkatesh at that time.
								</p>
								<p>
								God enters as a common man, and he introducing as Krishna that is none another then Power Star Pawan Kalyan. God entered in to Venkatesh life and after and what God want to give message to common peopls and society and why he came to earth? is the rest of the story.
								</p>



                            </div>
                            <br/>

									</div>
								 </div>
								 </div>

								   
		  						 <div class="clear"> </div>
							</div>
							<?php
							include("../googleanalytics.php");
							?>
		
	</body>
</html>

