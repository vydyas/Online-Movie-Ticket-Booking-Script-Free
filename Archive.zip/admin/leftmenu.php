<?php
session_start();
include_once('chk_login.php');
?>
<ul>
	<li><a href="addNewBooking.php">Add New</a></li>
	<li><a href="ticketBookList.php">View Booking</a></li>
</ul>