<?php
$date1=strtotime("2014-08-08");

$today = date("Ymd"); 

echo $today;

$date2=strtotime("2014-08-09");

echo $date1-$date2;


?>