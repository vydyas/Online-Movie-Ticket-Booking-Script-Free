<?php
header('Location:http://127.0.0.1/moviesearch/404.php');
?>