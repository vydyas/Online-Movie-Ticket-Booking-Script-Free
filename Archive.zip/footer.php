<header>
	<div class='footer-content'>
		<br/>
		Copyrights &copy; 2014 <a href="http://loginitsolutions.com" style="color:#3399ff" title="Login It Soltions" target="_blank">Login IT Solutions</a>. All are reserved.
		<br/><br/>
	</div>
</header>
