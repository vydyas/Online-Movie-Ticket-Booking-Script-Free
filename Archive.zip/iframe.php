<style type="text/css">
body
{
			margin: 0px;
		padding: 0px;
    overflow-y:hidden;

}
	#bar
	{
		background: #eee;
		width: 100%;
	    position: fixed;
	    box-shadow: 0px 1px 1px 1px #bdbdbd;
	    height: 45px;
	}
	#bar h2
	{
        font-family: Century gothic;
        margin-top: 5px;
	}
</style>
<body>
<div id="bar">
	<center><a herf="#"><h2><span style="color:red">Cinema</span><span style="color:#3399ff">Choodu</span>.com</h2></a></center>
</div><br/><br/><br/>
<iframe src="http://justickets.com/srikakulam" frameborder="0" scrolling="yes" height="100%" width="100%"></iframe>
</body>
