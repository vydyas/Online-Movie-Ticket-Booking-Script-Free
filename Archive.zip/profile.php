<a href="profile.php?name=siddhu&age=21">Link</a>
<?php $name=$_GET['name'];$age=$_GET['age'];?>
Hi this is <b><?php echo $name;?></b> and my age is <b><?php echo $age?></b>.